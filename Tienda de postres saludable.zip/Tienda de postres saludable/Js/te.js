// Función para mostrar u ocultar las opciones de té
function mostrarTe(idTe) {
    var te = document.getElementById(idTe);
    te.classList.toggle('oculto');
}

// Función para agregar al carrito según el té seleccionado
function agregarAlCarrito(nombreTe) {
    var cantidad = parseInt(document.querySelector('#' + nombreTe + ' .cantidad').value);
    var precioUnitario = obtenerPrecioUnitario(nombreTe);
    
    if (cantidad > 0 && precioUnitario > 0) {
        var precioTotal = cantidad * precioUnitario;
        // Aquí puedes manejar la lógica para agregar al carrito o realizar alguna acción con el precio total
        console.log('Se agregó al carrito: ' + nombreTe + ', Cantidad: ' + cantidad + ', Precio total: ' + precioTotal);
    } else {
        alert('Selecciona una cantidad válida.');
    }
}

// Función auxiliar para obtener el precio unitario del té seleccionado
function obtenerPrecioUnitario(nombreTe) {
    switch (nombreTe) {
        case 'Té Negro':
        case 'Té Verde':
        case 'Té Oolong':
        case 'Té Blanco':
        case 'Té Prensado':
            return 1800; // Precio para té clásico
        case 'Té de Japón (Sencha)':
        case 'Té Sweet Vanilla':
        case 'Té Rooibos':
        case 'Té Pu-erh':
        case 'Indian Chai':
            return 2500; // Precio para té especial
        default:
            return 0; // Por defecto
    }
}
