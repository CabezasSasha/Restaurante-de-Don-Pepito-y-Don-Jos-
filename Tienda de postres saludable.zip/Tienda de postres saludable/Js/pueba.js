document.addEventListener("DOMContentLoaded", function() {
    // Obtener botones principales y sus contenidos secundarios
    const toggleComidaSalada = document.getElementById("toggleComidaSalada");
    const grupoSandwichTostadas = document.querySelector(".GrupoDeMenu");

    // Mostrar u ocultar el grupo de Sandwich y Tostadas al hacer clic en Comida Salada
    toggleComidaSalada.addEventListener("click", function() {
        toggleElementVisibility(grupoSandwichTostadas);
    });

    // Función para mostrar u ocultar elementos
    function toggleElementVisibility(element) {
        element.classList.toggle("contenidoOculto");
    }

    // Evento para los botones secundarios (toggleMenu)
    const toggleMenus = document.querySelectorAll(".toggleMenu");

    toggleMenus.forEach(function(toggleMenu) {
        toggleMenu.addEventListener("click", function() {
            const menu = this.nextElementSibling; // El div .menu siguiente al botón .toggleMenu
            toggleElementVisibility(menu);
        });
    });
});

